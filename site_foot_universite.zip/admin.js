const motDePasse = "footadmin2025";

function checkPass() {
  const input = document.getElementById("adminPass").value;
  if (input === motDePasse) {
    document.getElementById("loginBox").style.display = "none";
    document.getElementById("adminContent").style.display = "block";
  } else {
    document.getElementById("errorMsg").textContent = "Mot de passe incorrect.";
  }
}

if (!localStorage.getItem("stats")) {
  localStorage.setItem("stats", JSON.stringify({ buteurs: [], passeurs: [] }));
}

function saveData(type, joueur, equipe, valeur) {
  const stats = JSON.parse(localStorage.getItem("stats"));
  stats[type].push({ joueur, equipe, [type === "buteurs" ? "buts" : "passes"]: valeur });
  localStorage.setItem("stats", JSON.stringify(stats));
  alert("Ajouté avec succès !");
}

document.getElementById("formButeur")?.addEventListener("submit", function (e) {
  e.preventDefault();
  const nom = document.getElementById("buteurNom").value;
  const equipe = document.getElementById("buteurEquipe").value;
  const buts = parseInt(document.getElementById("buteurButs").value);
  saveData("buteurs", nom, equipe, buts);
  this.reset();
});

document.getElementById("formPasseur")?.addEventListener("submit", function (e) {
  e.preventDefault();
  const nom = document.getElementById("passeurNom").value;
  const equipe = document.getElementById("passeurEquipe").value;
  const passes = parseInt(document.getElementById("passeurPasses").value);
  saveData("passeurs", nom, equipe, passes);
  this.reset();
});