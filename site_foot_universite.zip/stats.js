const stats = JSON.parse(localStorage.getItem("stats")) || { buteurs: [], passeurs: [] };

const buteursTable = document.getElementById("buteursTable");
const passeursTable = document.getElementById("passeursTable");

stats.buteurs.forEach(buteur => {
  const row = buteursTable.insertRow();
  row.innerHTML = `<td>${buteur.joueur}</td><td>${buteur.equipe}</td><td>${buteur.buts}</td>`;
});

stats.passeurs.forEach(passeur => {
  const row = passeursTable.insertRow();
  row.innerHTML = `<td>${passeur.joueur}</td><td>${passeur.equipe}</td><td>${passeur.passes}</td>`;
});